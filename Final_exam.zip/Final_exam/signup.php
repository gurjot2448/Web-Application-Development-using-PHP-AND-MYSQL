<html>
 <head>
  <title>Login</title>
 </head>
 <body>

<?php

//If Submit Button Is Clicked Do the Following
if(isset($_POST['Register'])){
$ID = $_POST["ID"];
$Name = $_POST["Name"];
	$Address = $_POST["Address"];
	$Phone = $_POST["Phone"];
	
if ($ID == "0")
{
	<script type="text/javascript">location.href = 'success.html';</script>
}
else
{
	header("Location: mylogin.php?flag=true", true, 301);
}

} ?>


//goes here after
<script>location.href='gamestore.php';</script>
	 
</body>
</html>



