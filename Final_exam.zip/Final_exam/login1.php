<?php

$usn = $_POST["un"];
$pwd = $_POST["pw"];
echo "The username passed is: " . $usn;
echo "The password passed is: " . $pwd;


if ($usn == "admin" && $pwd == "1234")
{
	header("Location: success.html", true, 301);
}
else
{
	header("Location: mylogin.php?flag=true", true, 301);
}

?>