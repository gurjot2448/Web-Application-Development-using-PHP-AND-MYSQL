<!DOCTYPE html>
<html>
<title>Question 1</title>

<head>
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}

 td {
    padding: 15px;
}
</style>
</head>





	
	
	<table>   
    <?php
        $file = fopen("gameinventory.txt", "r") or die("Unable to open file!");
        while (!feof($file)){   
            $data = fgets($file); 
            list($ID,$Name,$Image,$Quantity,$Price) = explode("|", $data);
    ?> 
    <h2>GamestoreInfo Table</h2>
	<tr>
      <th>ID</th>
      <th>Name</th>
      <th>Image</th>
	  <th>Quantity</th>
      <th>Price</th>
      
    </tr>
    <tr>
      <td>0</td>
      <td>Barbie</td>
      <td><img src=C:\xampp\htdocs\Final_exam align="center" ></img></td>
	  <td>5</td>
      <td>500</td>
      
    </tr>
    <tr>
      <td>1</td>
      <td>horror</td>
      <td><img src=C:\xampp\htdocs\Final_exam align="center"></td>
	  <td>6</td>
      <td>800</td>
      
    </tr>
    <tr>
      <td>2</td>
      <td>candy_crush</td>
      <td><img src=C:\xampp\htdocs\Final_exam align="center"></td>
	  <td>1</td>
      <td>1000</td>
      
    </tr>
	
	
    <?php
        }
        fclose($failas);
   ?>
   
</table>

</html>


