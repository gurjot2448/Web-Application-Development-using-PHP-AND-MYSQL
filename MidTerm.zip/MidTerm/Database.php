<html>
	<head>
		<title>2</title>
	</head>
	<body>
		 <?php
			$servername = "localhost";
			$username = "root";
			$password = "";
			$db = "midterm";

			$conn = new mysqli($servername, $username, $password, $db);

			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			}
			//echo "Connected successfully";
			
			
			//insertion of 10 records
			mysqli_query($conn, "INSERT INTO `pets` (`PetName`, `PetID`, `DateOfBirth`, `Price`, `DateSoled`) VALUES ('A', '1', '2011-06-09 00:00:00', '99', '2018-10-01 00:00:00')");
			mysqli_query($conn, "INSERT INTO `pets` (`PetName`, `PetID`, `DateOfBirth`, `Price`, `DateSoled`) VALUES ('B', '2', '2015-06-09 00:00:00', '212', '2018-09-01 00:00:00')");
			mysqli_query($conn, "INSERT INTO `pets` (`PetName`, `PetID`, `DateOfBirth`, `Price`, `DateSoled`) VALUES ('C', '3', '2012-06-09 00:00:00', '135', '2017-10-01 00:00:00')");
			mysqli_query($conn, "INSERT INTO `pets` (`PetName`, `PetID`, `DateOfBirth`, `Price`, `DateSoled`) VALUES ('D', '4', '2013-06-09 00:00:00', '363', '2018-10-05 00:00:00')");
			mysqli_query($conn, "INSERT INTO `pets` (`PetName`, `PetID`, `DateOfBirth`, `Price`, `DateSoled`) VALUES ('E', '5', '2014-06-09 00:00:00', '562', '2015-10-21 00:00:00')");
			mysqli_query($conn, "INSERT INTO `pets` (`PetName`, `PetID`, `DateOfBirth`, `Price`, `DateSoled`) VALUES ('F', '6', '2015-06-09 00:00:00', '232', '2018-10-01 00:00:00')");
			mysqli_query($conn, "INSERT INTO `pets` (`PetName`, `PetID`, `DateOfBirth`, `Price`, `DateSoled`) VALUES ('G', '7', '2016-06-09 00:00:00', '231', '2018-10-01 00:00:00')");
			mysqli_query($conn, "INSERT INTO `pets` (`PetName`, `PetID`, `DateOfBirth`, `Price`, `DateSoled`) VALUES ('H', '8', '2017-06-09 00:00:00', '123', '2017-11-01 00:00:00')");
			mysqli_query($conn, "INSERT INTO `pets` (`PetName`, `PetID`, `DateOfBirth`, `Price`, `DateSoled`) VALUES ('I', '9', '2017-06-09 00:00:00', '963', '2018-09-11 00:00:00')");
			mysqli_query($conn, "INSERT INTO `pets` (`PetName`, `PetID`, `DateOfBirth`, `Price`, `DateSoled`) VALUES ('J', '10', '2010-06-09 00:00:00', '545', '2018-09-21 00:00:00')");
		
			
		?> 
		
		<h1>Age > 5 years</h1>
		<?php
			$result = mysqli_query($conn,"SELECT `PetName`,`DateOfBirth`, `Price`, `DateSoled`, TIMESTAMPDIFF(YEAR, DateOfBirth, CURRENT_DATE) AS age FROM pets");

			echo "<table border='1'>
			<tr>
				<th>PetName</th>
				<th>DateOfBirth</th>
				<th>Price</th>
				<th>DateSoled</th>
			</tr>";

			while($row = mysqli_fetch_array($result))
			{
				if($row['age']  >= 5){
					echo "<tr>";
					echo "<td>" . $row['PetName'] . "</td>";
					echo "<td>" . $row['DateOfBirth'] . "</td>";
					echo "<td>" . $row['Price'] . "</td>";
					echo "<td>" . $row['DateSoled'] . "</td>";
					echo "</tr>";
				}
			}
			echo "</table>";
		?>
		
		<h1>Prices Last 7 Days</h1>
		<?php
			$result = mysqli_query($conn,"SELECT `PetName`,`DateOfBirth`, `Price`, `DateSoled` FROM pets WHERE `DateSoled` >= DATE(NOW()) - INTERVAL 7 DAY ORDER BY `Price` DESC");

			echo "<table border='1'>
			<tr>
				<th>PetName</th>
				<th>DateOfBirth</th>
				<th>Price</th>
				<th>DateSoled</th>
			</tr>";

			while($row = mysqli_fetch_array($result))
			{	
				echo "<tr>";
				echo "<td>" . $row['PetName'] . "</td>";
				echo "<td>" . $row['DateOfBirth'] . "</td>";
				echo "<td>" . $row['Price'] . "</td>";
				echo "<td>" . $row['DateSoled'] . "</td>";
				echo "</tr>";				
			}
			echo "</table>";
		?>
	
	</body>
</html>