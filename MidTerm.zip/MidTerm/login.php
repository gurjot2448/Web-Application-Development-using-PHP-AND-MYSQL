<html>
	<head>
		
		<style>
			.error{
				color:blue;
			}
		</style>
	</head>
	<body>
		<form action="success.html" method="POST">
			<input type="text" name="username" placeholder="Enter Username"/><br>
			<input type="password" name="password" placeholder="Enter Password"><br>
			<input type="password" name="confirm_password" placeholder="Enter Password Again"><br>
			<input type="submit" name="submit" value="submit"/>
		</form>	
	</body>

</html>

<?php 

if(isset($_POST["submit"])){
	$username = $_POST["username"];
	$password = $_POST["password"];
	$confirm_password = $_POST["confirm_password"];
	$length = strlen($password);
	
	if(ctype_lower($username)){
		if($length >= 8){
			if(preg_match("/^[a-zA-Z]+$/", $password) == 1) {
				if($password == $confirm_password){
					echo "<p>Data Okay!<p>"; ?>
					<script type="text/javascript">location.href = 'success.html';</script>
					<?php
				}else{
					echo "<p class='error'>Both passwords must be same!</p>";
				}
			}else{
				echo "<p class='error'>Password must contain characters from a-z or A-Z only!</p>";
			}
		}else{
			echo "<p class='error'>Password length must be 8 characters!</p>";
		}
	}else{
		echo "<p class='error'>Username must contain lowercase letters only!</p>";
	}
}

?>